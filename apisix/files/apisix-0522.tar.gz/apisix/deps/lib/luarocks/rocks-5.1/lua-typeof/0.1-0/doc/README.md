# lua-typeof
Check the data type for Lua variable

## Install

```shell
luarocks install typeof
```
